package com.hotelapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.hotelapp.model.Hotel;
import com.hotelapp.service.HotelService;

@Controller
public class HotelController {

	@Autowired
	HotelService hotelService;
	
	@GetMapping("/hotels")
	public ResponseEntity<List<Hotel>> getAllHotels(){
		List<Hotel> hotelList=hotelService.getAllHotels();
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(hotelList);
		
	}
	@PostMapping("/hotel")
	public ResponseEntity<Hotel> addHotel(@RequestBody Hotel hotel){
		Hotel hotel1=hotelService.addHotel(hotel);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(hotel1);
		
	}
	
}
