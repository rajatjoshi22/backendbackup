package com.bookapp.exceptions;

public class BookAlreadyExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookAlreadyExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
