package com.booklapp.exceptions;

public class BookIdNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookIdNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
