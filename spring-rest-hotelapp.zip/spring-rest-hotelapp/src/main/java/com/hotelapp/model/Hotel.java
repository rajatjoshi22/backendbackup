package com.hotelapp.model;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Hotel {
	@Id
	@Column(name="hotelid")
private Integer hotelId;
	@Column(name="hotelname")
private String hotelName;
private String reviews;
@ManyToMany(cascade = CascadeType.ALL)
@JoinTable(name="Hiberhotel_cuisine",joinColumns= {@JoinColumn(name="hotel_id")},inverseJoinColumns = {@JoinColumn(name="cuisine_id")})
private Set<Cuisine> cuisinelist;
@OneToOne(cascade ={CascadeType.ALL})
@JoinColumn(name="address_id")
private Address address;
@OneToMany(mappedBy="hotel",cascade = CascadeType.ALL)
private Set<Menu> menulist;
}
