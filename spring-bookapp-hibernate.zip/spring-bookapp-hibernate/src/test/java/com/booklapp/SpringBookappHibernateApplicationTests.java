package com.booklapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBookappHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
