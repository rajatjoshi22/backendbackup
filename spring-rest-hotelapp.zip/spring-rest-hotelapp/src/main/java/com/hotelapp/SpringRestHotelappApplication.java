package com.hotelapp;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.hotelapp.model.Address;
import com.hotelapp.model.Cuisine;
import com.hotelapp.model.Hotel;
import com.hotelapp.model.Menu;
import com.hotelapp.service.HotelService;
import com.hotelapp.service.HotelServiceImpl;

@SpringBootApplication
public class SpringRestHotelappApplication implements  CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringRestHotelappApplication.class, args);
	}

	
@Autowired
HotelService hotelService;
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
	
		Address address=new Address("Delhi","Civil Lines",12678);
		Menu menu1=new Menu();
		menu1.setMenuName("Paneer Platter");
		menu1.setCategory("maincourse");
		menu1.setPrice(250.0);
		menu1.setType("veg");
		Menu menu2=new Menu();
		menu2.setMenuName("Chinese Platter");
		menu2.setCategory("Starter");
		menu2.setPrice(150.0);
		menu2.setType("veg");
		Menu menu3=new Menu();
		menu3.setMenuName("Drinks platter");
		menu3.setCategory("bewerage");
		menu3.setPrice(250.0);
		menu3.setType("drinks");
		Set<Menu> menuList=new HashSet<>(Arrays.asList(menu1,menu2,menu3));
		Cuisine cuisine=new Cuisine();
		cuisine.setCuisineName("North Indian");
		Set<Cuisine> cuList=new HashSet<>(Arrays.asList(cuisine));
	   Hotel hotel=new Hotel(123,"Abc Hotel","Excellent",cuList,address,menuList);
	   hotelService.addHotel(hotel);
	}

}
