package com.booklapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBookappHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBookappHibernateApplication.class, args);
	}

}
