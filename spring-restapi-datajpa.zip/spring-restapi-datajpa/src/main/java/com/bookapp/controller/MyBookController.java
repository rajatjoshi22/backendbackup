package com.bookapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.bookapp.model.Book;
import com.bookapp.service.BookService;

@RestController
public class MyBookController {
	@Autowired
	BookService bookService;
	
	@PostMapping("/Book")
	public ResponseEntity<Void>addBook(@RequestBody Book book) {
	  HttpStatus status=HttpStatus.ACCEPTED;
	  HttpHeaders headers=new HttpHeaders();
	  headers.add("message","Adding One book data");
	  bookService.addBook(book);
	  return ResponseEntity.status(status).headers(headers).build();
	  
	}
	
	@DeleteMapping("/Book")
    public ResponseEntity<String> deleteBook(@RequestParam("bookId")Integer bookId) {
		HttpStatus status=HttpStatus.ACCEPTED;
		  HttpHeaders headers=new HttpHeaders();
		  headers.add("message","deleting One book data");
		  bookService.deleteBook(bookId);
		return ResponseEntity.status(status).headers(headers).body("book deleted successfully!!!!!");
	}
	
	@PutMapping("/Book")
	public ResponseEntity<String> updateBook(@RequestBody Book book) {
		HttpStatus status=HttpStatus.ACCEPTED;
		  HttpHeaders headers=new HttpHeaders();
		  headers.add("message","Updating One book data");
		bookService.updateBook(book.getBookId(), book.getBookPrice());
		return ResponseEntity.status(status).headers(headers).body("Book updated successfully!!!!");
		
	}
	
	   @GetMapping("/getAllBooks")
	   public ResponseEntity<List<Book>> getAllBooks(){
		   HttpStatus status=HttpStatus.FOUND;
			  HttpHeaders headers=new HttpHeaders();
			  headers.add("message","getting All Books");
		   List<Book> bookList= bookService.getAllBooks();
		   return ResponseEntity.status(status).headers(headers).body(bookList);
	   }
	
	   @GetMapping("/getByChoice")
	   public ResponseEntity<List<Book>> getByChoice(@RequestParam("choice")String choice){
		   HttpStatus status=HttpStatus.FOUND;
			  HttpHeaders headers=new HttpHeaders();
			  headers.add("message","getting Book by choice!!!!");
		  List<Book> bookList= bookService.getByChoice(choice);
		  return ResponseEntity.status(status).headers(headers).body(bookList);
	   } 
	   
	   @GetMapping("/getById")
	public ResponseEntity<Book> getById(@RequestParam("bookId")Integer bookId) {
		   HttpStatus status=HttpStatus.FOUND;
			  HttpHeaders headers=new HttpHeaders();
			  headers.add("message","getting Book by Id!!!!");
		   Book book= bookService.getById(bookId);
		   return ResponseEntity.status(status).headers(headers).body(book);
	   } 
	
	
}